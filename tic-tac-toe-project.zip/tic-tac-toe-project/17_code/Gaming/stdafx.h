// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
#pragma once

// TODO: reference additional headers your program requires here

#include <string.h>			// for memset() - used in clearing a buffer
#include <math.h>			// for abs()
#include <conio.h>			// for getch()
#include <stdlib.h>
#include <vector>
#include <float.h>
#include<iostream>
#include<fstream>
#include<windows.h>
using namespace std;