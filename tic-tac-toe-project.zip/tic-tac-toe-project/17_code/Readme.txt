The path provided in macro definition of help.h is default by our system path.
Just Build and debug will run the program without any error.